require("sinatra")
require("sqlite3")
require "sinatra/activerecord"

set(:database, {adapter: "sqlite3", database: "movies.db"})

class User < ActiveRecord::Base
end

class RedditApp < Sinatra::Base
  register(Sinatra::ActiveRecordExtension)

  # Index of all users
  get("/u/all") do
    # "The user is #{User.last.name} and his age is #{User.last.age}"
    @users = User.all
    return erb(:user_all)
  end

  # Form for new user
  get("/u/new") do
    erb(:new_user)
  end

  # Show page for individual user
  get("/u/:name") do
    @user = User.find_by({name: params[:name]})
    # @user = User.where({name: params[:name]}).take
    if @user
      return erb(:show_user)
    else
      return "No user found by that name"
    end
  end

  # Create the user in the database
  post("/u/new") do
    @user = {name: params[:name], age: params[:age]}
    User.create(@user)
    redirect "/u/all"
  end

   # Send the update user form
   get("/u/update/:name") do
     # ActiveRecord query to find the user by name
     # put it in an instance variable
     # use that instance variable in the template

     @user = User.find_by({name: params[:name]})
     erb(:update_user)
   end

   # Update user
   patch("/u/:name") do
    @user = User.find_by({name: params[:name]})
    @user.update({name: "something else"})

    if @user.save
      return "Succesully updated record"
    else
      return "No user found by that name"
    end

   end
   # Destroy user

   get("/m/all") do
     "List all movies here"
   end

  # Welcome message
  get("/") do
    "Welcome to my app"
  end
end
